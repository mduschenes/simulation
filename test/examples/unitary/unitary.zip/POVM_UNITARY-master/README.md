# POVM_UNITARY
To run do python GHZ.py 0 # starts calculation from scratch
